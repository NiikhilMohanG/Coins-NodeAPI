This folder contains all the business related activities
