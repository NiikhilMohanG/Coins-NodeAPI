
var User = require("./../contracts/user");
var UserDataService = require("./../data/user.data");

var UserBusiness = {
    GetUserDetails:function(_userid){
        return UserDataService.
    }

}
