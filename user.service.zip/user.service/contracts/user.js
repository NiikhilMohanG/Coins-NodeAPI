
class User {
    FirstName;
    MiddleName;
    LastName;
    Age;
    ContactNumber;
    Nationality;
    Email;
    Address;
    PinCode;
    State;
    Country;
    CountryCode;
    UserName;
    Password;
    ProfilePicture;
    UserType;
    MappedRoleId;
    IsActive;
    UserRatings;
    IsBannedUser;
    CreatedDate;
    ModifiedDate;
    CreatedBy;
    ModifiedBy;
}

module.exports = User;