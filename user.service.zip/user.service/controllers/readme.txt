This folder contains the controller methods

Sample controller template should be


var base = require("coins-shared-utils");
var app = base.CoinsApp;


base.InvokeServer(app);


Refer sample.js for more details
Do comment on each method about functionality
